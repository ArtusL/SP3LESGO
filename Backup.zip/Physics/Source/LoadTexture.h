/*
\author Lim Chian Song
*/
#ifndef LOAD_TEXTURE_H
#define LOAD_TEXTURE_H

GLuint LoadTexture(const char* file_path, const bool bInvert = false);

#endif